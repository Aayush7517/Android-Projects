package com.example.mybeaconobserver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.mybeaconobserver.R;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    BluetoothAdapter mBluetoothAdapter;
    ScanFilter mScanFilter;
    ScanSettings mScanSettings;
    BluetoothLeScanner mBluetoothLeScanner;
    boolean fineLocationPermissionGranted = false;
    boolean readPermissionGranted = false;
    boolean writePermissionGranted = false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            System.out.println("to request for permission");
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 123);

            System.out.println("permission not enabled");
            return;
        } else {
            fineLocationPermissionGranted = true;
        }
// request for other permission needed (for my project, I need read/write permissions
// because I want to log the data
// before return from onCreate(), call a function to prepare for scanning
        prepareForScanning();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 123:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    fineLocationPermissionGranted = true;
                } else {
                    fineLocationPermissionGranted = false;
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        if (fineLocationPermissionGranted) {
            prepareForScanning();
        }
    }

    private void prepareForScanning() {
        final BluetoothManager btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = btManager.getAdapter();
        mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();

        // setScanFilter();
        setScanSettings();

        ToggleButton toggle = (ToggleButton) findViewById(R.id.tbtnScan);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    //mBluetoothLeScanner.startScan(Arrays.asList(mScanFilter), mScanSettings, mScanCallback);
                    mBluetoothLeScanner.startScan(null, mScanSettings, mScanCallback);
                } else {
                    // The toggle is disabled
                    mBluetoothLeScanner.stopScan(mScanCallback);
                }
            }
        });
    }

    private void setScanFilter() {
        ScanFilter.Builder mBuilder = new ScanFilter.Builder();
        ByteBuffer mManufacturerData = ByteBuffer.allocate(23);
        ByteBuffer mManufacturerDataMask = ByteBuffer.allocate(24);
        byte[] uuid = UUID.fromString("D0D3FA86-CA76-45EC-9BD9-6AF49D4E0D0F").toString().getBytes();
        mManufacturerData.put(0, (byte) 0xBE);
        mManufacturerData.put(1, (byte) 0xAC);
        for (int i = 2; i <= 17; i++) {
            mManufacturerData.put(i, uuid[i - 2]);
        }
        for (int i = 0; i <= 17; i++) {
            mManufacturerDataMask.put((byte) 0x01);
        }
        mBuilder.setManufacturerData(224, mManufacturerData.array(), mManufacturerDataMask.array());
        mScanFilter = mBuilder.build();
    }

    private void setScanSettings() {
        ScanSettings.Builder mBuilder = new ScanSettings.Builder();
        mBuilder.setReportDelay(0);
        mBuilder.setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY);
        mScanSettings = mBuilder.build();
    }

    protected ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            ScanRecord mScanRecord = result.getScanRecord();
            byte[] manufacturerData = mScanRecord.getManufacturerSpecificData(224);
            int mRssi = result.getRssi();
                   //long ts = result.getTimestampNanos() / 1000000; //
            int txpw; // = result.getTxPower();

            byte[] scanData = mScanRecord.getBytes();
            int startByte = 2;
            boolean patternFound = false;
            while (startByte <= 5) {
                if (((int) scanData[startByte + 2] & 0xff) == 0x02 && //Identifies an iBeacon
                        ((int) scanData[startByte + 3] & 0xff) == 0x15) { //Identifies correct data length
                    patternFound = true;
                    break;
                }
                startByte++;
            }

            if (patternFound) {
                System.out.println("iBeacon Packet: " + bytesToHexString(scanData));
                // UUID uuid = getGuidFromByteArray(Arrays.copyOfRange(scanData, 9, 25));
                UUID uuid = getGuidFromByteArray(Arrays.copyOfRange(scanData, startByte + 4, startByte + 20));
                int major = (scanData[startByte + 20] & 0xff) * 0x100 + (scanData[startByte + 21] & 0xff);
                int minor = (scanData[startByte + 22] & 0xff) * 0x100 + (scanData[startByte + 23] & 0xff);
                txpw = scanData[startByte + 24];
                double accuracy = calculateAccuracy(txpw, mRssi);
                String distStr = getDistance(accuracy);

                // set textView on beacon information
                TextView lbl = (TextView) findViewById(R.id.lbUUID);
                lbl.setText(""+uuid);
                lbl = (TextView) findViewById(R.id.lbMajor);
                lbl.setText(""+major);
                lbl = (TextView) findViewById(R.id.lbMinor);
                lbl.setText(""+minor);
                lbl = (TextView) findViewById(R.id.lbAccuracy);
                lbl.setText(""+accuracy);
                lbl = (TextView) findViewById(R.id.lbDistance);
                lbl.setText(distStr);
                lbl = (TextView) findViewById(R.id.lbRSSI);
                lbl.setText(""+mRssi);


            }
        }
    };

    public double calculateAccuracy(int txPower, double rssi) {
        if (rssi == 0) {
            return -1.0; // if we cannot determine accuracy, return -1.
        }
        double ratio = rssi*1.0/txPower;
        if (ratio < 1.0) {
            return Math.pow(ratio,10);
        }
        else {
            double accuracy =  (0.89976)*Math.pow(ratio,7.7095) + 0.111;
            return accuracy;
        }
    }

    private String getDistance(double accuracy) {
        if (accuracy == -1.0) {
            return "Unknown";
        } else if (accuracy < 1) {
            return "Immediate";
        } else if (accuracy < 3) {
            return "Near";
        } else {
            return "Far";
        }
    }

    public  String bytesToHexString(byte[] bytes) {
        StringBuilder buffer = new StringBuilder();
        for(int i=0; i<bytes.length; i++) {
            buffer.append(String.format("%02x", bytes[i]));
        }
        return buffer.toString();
    }

    public  UUID getGuidFromByteArray(byte[] bytes)
    {
        ByteBuffer bb = ByteBuffer.wrap(bytes);
        UUID uuid = new UUID(bb.getLong(), bb.getLong());
        return uuid;
    }


}