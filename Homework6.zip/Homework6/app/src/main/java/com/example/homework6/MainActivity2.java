package com.example.homework6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    EditText name,mob,csu;
    Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name = findViewById(R.id.name);
        mob = findViewById(R.id.mobile);
        csu = findViewById(R.id.csuid);         // Initilization
        btn2 = findViewById(R.id.submit);

        final databasehelp dbh = new databasehelp(this);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name1 = name.getText().toString();
                String n1 = mob.getText().toString();
                String csu1 = csu.getText().toString();

                String value = dbh.addRecord(name1,n1,csu1);
               // Toast.makeText(getApplicationContext(), "aayush", 500);

                Intent i = new Intent(MainActivity2.this, MainActivity.class);

                i.putExtra("namekey", name1);
                i.putExtra("mobkey", n1);
                i.putExtra("csukey", csu1);

                startActivity(i);
            }
        });


    }
}