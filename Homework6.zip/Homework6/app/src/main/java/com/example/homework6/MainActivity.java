package com.example.homework6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button bt;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final ListView lv = (ListView)findViewById(R.id.lvw);
       Button bt = (Button)findViewById(R.id.button2);

        new databasehelp(this);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // System.out.println("aayush");
                Intent i = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(i);
            }
        });

        String name1 = getIntent().getStringExtra("namekey");
        final String mob1 = getIntent().getStringExtra("mobkey");
        final String csu1 = getIntent().getStringExtra("csukey");

        if(name1 == null || name1.length()==0)
            name1 = "Empty now";

      //  String s1 = name1;


        ArrayList<String> s = new ArrayList<>();
        s.add(name1);

        ArrayAdapter ar = new ArrayAdapter(this,android.R.layout.simple_list_item_1,s);
        lv.setAdapter(ar);

        final String finalName = name1;
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

               Intent j = new Intent(MainActivity.this, MainActivity3.class);

                j.putExtra("namekey", finalName);
                j.putExtra("mobkey", mob1);
                j.putExtra("csukey", csu1);

               startActivity(j);
            }
        });
    }
}