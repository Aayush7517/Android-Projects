package com.example.homework6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        textView = findViewById(R.id.showview);
        String name2 = getIntent().getStringExtra("namekey");
        String mob2 = getIntent().getStringExtra("mobkey");
        String csu2 = getIntent().getStringExtra("csukey");

        textView.setText(name2 + "\n" + mob2 + "\n" + csu2);

    }
}