package com.example.homework6;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class databasehelp extends SQLiteOpenHelper {

    private static final String dname= "studentdb.db";
    public databasehelp(Context context) {
        super(context, dname, null  , 1 );
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String qry = "create table student (name text, mobile text primary key, csuid text)";
        sqLiteDatabase.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists student");
        onCreate(sqLiteDatabase);
    }

        public String addRecord(String p1, String p2, String p3)
        {
            SQLiteDatabase sq = this.getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("name", p1);
            cv.put("mobile", p2);
            cv.put("csuid", p3);

            long res = sq.insert("student", null,cv);
            if (res == -1)
                return "failed";
            else
                return "successfully inserted";
        }
}
