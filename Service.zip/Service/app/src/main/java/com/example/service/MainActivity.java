package com.example.service;

import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    IntentFilter intentFilter;
    IntentFilter intentFilter1;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar=findViewById(R.id.progressBar);
        progressBar.setMax(100);
        progressBar.setProgress(0);
    }
    public void startService(View view) {
        startService(new Intent(getBaseContext(), ServiceApp.class));
        progressBar.setVisibility(View.VISIBLE);
    }
    public void stopService(View view) {
        stopService(new Intent(getBaseContext(), ServiceApp.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        intentFilter = new IntentFilter();
        intentFilter1 = new IntentFilter();
        intentFilter.addAction("file_download_progress");
        registerReceiver(intentReceiver, intentFilter);
    }
    private BroadcastReceiver intentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("TAG", "onReceive: "+intent.getAction());
            progressBar.setProgress(intent.getIntExtra("progress",0));
            if(intent.getIntExtra("progress",0)==100) {
                progressBar.setVisibility(View.GONE);
            }
            if(intent.getIntExtra("progress",-1)==-1){
                progressBar.setVisibility(View.GONE);

            }
        }
    };


    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(intentReceiver);

    }
}