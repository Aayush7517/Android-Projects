package com.example.myapplication5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {               //main class start

    TextView tw;
    ConstraintLayout c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);                                // oncreate method
        setContentView(R.layout.activity_main);
        tw = findViewById(R.id.aayu);
        tw.setVisibility(tw.INVISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater m = getMenuInflater();                                //create method for menu
        m.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
               // variable connection
        c = findViewById(R.id.con);

        switch (item.getItemId())
        {
            case R.id.first:
                tw.setVisibility(tw.VISIBLE);
                tw.setX(0);
                tw.setY(0);
                return true;

            case R.id.second:
                tw.setVisibility(tw.VISIBLE);
                tw.setX(950);
                tw.setY(0);
                return true;

            case R.id.third:
                tw.setVisibility(tw.VISIBLE);
                tw.setX(0);
                tw.setY(2300);
                return true;

            case R.id.fourth:
                tw.setVisibility(tw.VISIBLE);
                tw.setX(950);
                tw.setY(2300);
                return true;

            case R.id.fifth:
                tw.setVisibility(tw.INVISIBLE);
                return true;



            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
