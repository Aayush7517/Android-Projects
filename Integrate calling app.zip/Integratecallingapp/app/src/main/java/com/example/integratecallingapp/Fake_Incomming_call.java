package com.example.integratecallingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Fake_Incomming_call extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fake__incomming_call);
    }
}