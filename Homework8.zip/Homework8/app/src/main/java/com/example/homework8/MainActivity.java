package com.example.homework8;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Databasehelper db;
    Button add_data;
    EditText add_name;
    ArrayList<String> Listitem;
    ArrayAdapter adapter;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new Databasehelper(this);
        Listitem = new ArrayList<>();
        add_data = findViewById(R.id.submit);
        add_name = findViewById(R.id.name);
        lv = findViewById(R.id.lv);
        viewdata();


        add_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = add_name.getText().toString();
                if(!name.equals("") && db.insertData(name)){
                    Toast.makeText(MainActivity.this,"Data added",Toast.LENGTH_SHORT).show();
                    add_name.setText("");
                    Listitem.clear();
                    viewdata();
                }else{
                    Toast.makeText(MainActivity.this,"data not added",Toast.LENGTH_SHORT).show();
                }
            }
        });

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String text = lv.getItemAtPosition(i).toString();
                Toast.makeText(MainActivity.this,""+text,Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void viewdata(){
        Cursor cursor = db.viewdata();
        if(cursor.getCount() == 0)
             Toast.makeText(this,"no data to show", Toast.LENGTH_SHORT).show();
        else
        {
            while(cursor.moveToNext()){
                Listitem.add(cursor.getString(1));
            }
            adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,Listitem);
            lv.setAdapter(adapter);
        }
    }

}