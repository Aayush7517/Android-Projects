package com.example.homework8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Databasehelper extends SQLiteOpenHelper {

private static final String DB_Name = "Users.db";
private static final String DB_Table = "Users_table";

private static final String ID = "ID";
private static final String NAME = "NAME";

 private static final String CREATE_TABLE = "CREATE TABLE " + DB_Table + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NAME +
        " TEXT "+ " ) ";

    public Databasehelper(Context context)
    {
        super(context,DB_Name,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if EXISTS " + DB_Table);
        onCreate(sqLiteDatabase);
    }

    public boolean insertData(String name)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(NAME, name);
        long res = db.insert(DB_Table,null,cv);

        return res != -1;

    }

    public Cursor viewdata(){
        SQLiteDatabase db = this.getReadableDatabase();
        String querry = "select *  from "+DB_Table;
        Cursor cursor = db.rawQuery(querry,null);
        return cursor;
    }
}
