package com.example.fragments_final;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class frag2 extends Fragment {

    View view;
    Button b1,b2,bc,bd;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        view  = inflater.inflate(R.layout.fragment_frag2, container, false);
        b1 = view.findViewById(R.id.a);
        b2 = view.findViewById(R.id.b);
        bc = view.findViewById(R.id.c);
        bd = view.findViewById(R.id.d);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle result = new Bundle();
                result.putString("df1","A");
                getParentFragmentManager().setFragmentResult("datafrom1",result);
            }
        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle result = new Bundle();
                result.putString("df2","B");
                getParentFragmentManager().setFragmentResult("datafrom2",result);
            }
        });


        bc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle result = new Bundle();
                result.putString("df3","C");
                getParentFragmentManager().setFragmentResult("datafrom3",result);
            }
        });


        bd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle result = new Bundle();
                result.putString("df4","D");
                getParentFragmentManager().setFragmentResult("datafrom4",result);
            }
        });

        return view;
    }
}