package com.example.fragments_final;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class frag1 extends Fragment {


 View view;
 TextView tv;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


    view =  inflater.inflate(R.layout.fragment_frag1, container, false);
    tv = view.findViewById(R.id.tv1);
    getParentFragmentManager().setFragmentResultListener("datafrom1", this, new FragmentResultListener() {
        @Override
        public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
            String data = result.getString("df1");
            tv.append(data);
        }
    });


        getParentFragmentManager().setFragmentResultListener("datafrom2", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                String data = result.getString("df2");
                tv.append(data);
            }
        });

        getParentFragmentManager().setFragmentResultListener("datafrom3", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                String data = result.getString("df3");
                tv.append(data);
            }
        });


        getParentFragmentManager().setFragmentResultListener("datafrom4", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(@NonNull String requestKey, @NonNull Bundle result) {
                String data = result.getString("df4");
                tv.append(data);
            }
        });


    return view;
    }
}