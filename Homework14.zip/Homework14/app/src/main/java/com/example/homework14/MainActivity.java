package com.example.homework14;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;

import com.example.homework14.R;

 public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private float x, y, z, last_x, last_y, last_z;
    private boolean isFirstValue;

     private MediaPlayer qMediaPlayer;
    private float shakeThreshold = 3f;
    int a=0;

    private MediaPlayer mMediaPlayer, vMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.mario);
        vMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.titanic);
        qMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.kabira);
    }

    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this, mAccelerometer);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        x = event.values[0];
        y = event.values[1];
        z = event.values[2];
        if (isFirstValue) {
            float deltaX = Math.abs(last_x - x);
            float deltaY = Math.abs(last_y - y);
            float deltaZ = Math.abs(last_z - z);
            // If the values of acceleration have changed on at least two axes, then we assume that we are in
            // a shake motion
            if ((deltaX > shakeThreshold && deltaY > shakeThreshold)
                    || (deltaX > shakeThreshold && deltaZ > shakeThreshold)
                    || (deltaY > shakeThreshold && deltaZ > shakeThreshold)) {

                if(a==0) {
                    a=1;
                    if(qMediaPlayer.isPlaying()) {
                        qMediaPlayer.pause();
                    }
                    vMediaPlayer.start();
                }
              else  if(a==1) {
                    a=2;
                    if(vMediaPlayer.isPlaying()) {
                        vMediaPlayer.pause();
                    }
                    mMediaPlayer.start();
                }
             else   if(a==2) {
                    a=0;
                    if(mMediaPlayer.isPlaying()) {
                        mMediaPlayer.pause();
                    }
                    qMediaPlayer.start();
                }
            }
        }


        last_x = x;
        last_y = y;
        last_z = z;
        isFirstValue = true;

    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }
}

